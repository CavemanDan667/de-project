from datetime import datetime


def get_time():
    '''
    Arguments - None
    Returns - Returns the current time when invoked
    Raises - None
    '''
    now = datetime.now()
    return now
